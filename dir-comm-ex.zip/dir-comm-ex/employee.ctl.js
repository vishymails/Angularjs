'use strict';

app.controller('EmployeeCtrl', ['$scope',
  function ($scope) {
  }
]);