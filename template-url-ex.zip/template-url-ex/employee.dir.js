'use strict';

app.directive("myEmployee", function () {
  return {
    templateUrl: 'employee.tpl.html'
  };
});
